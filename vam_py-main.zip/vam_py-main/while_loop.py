#while loop is used to perform iteration until condition will false.

#Print the numbers from 1 to 10 using wile loop.
x = 1

while x < 11:
    print(x)
    x=x+1

#Print the numbers from 10 to 1 using while loop.
x = 10
while x > 0:
    print(x)
    x=x-1

#To print the given pattern using while loop 1 3 5 9 11 
x = 1
while x < 12:
    if x % 2 != 0 and x != 7:
        print(x)
    x = x+1 

#To print the given pattern using while loop 1 3 5 9 11.
x = 1
while x<12:
    if x == 7:
        print()
    else:
        print(x)
    a=a+2
