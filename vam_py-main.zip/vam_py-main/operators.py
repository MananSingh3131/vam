# input from user and multiply

a = int(input('Enter number: '))
b = int(input('Enter number: '))
c = a*b
print(c)

# assignment operator
a = 10
a //= 10  
# a = a//10
print(a)
